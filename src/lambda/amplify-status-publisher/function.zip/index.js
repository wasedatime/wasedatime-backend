const https = require('https')

exports.handler = async (event) => {
    const sns = event.Records[0].Sns.Message
    let color = ''
    
    const data = JSON.stringify({
        attachments: [
            {
                'mrkdwn_in': ['text'],
                fallback: sns,
                color,
                text: sns
            }
        ]
    })
    
    return new Promise((resolve, reject) => {
        const request = https.request(process.env.WEBHOOK_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length,
            }
        }, (res) => {
            console.log(`statusCode: ${res.statusCode}`)
            res.on('data', (d) => process.stdout.write(d))
            res.on('end', () => resolve())
        })
        request.write(data)
        request.end()
    })
}