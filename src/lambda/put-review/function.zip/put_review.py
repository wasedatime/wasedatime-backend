import json
import boto3
from boto3.dynamodb.conditions import Key
from decimal import Decimal
from re import fullmatch
import uuid

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return json.JSONEncoder.default(self, obj)

def bad_referer(headers):
    if "referer" not in headers:
        return True
    elif fullmatch('https:\/\/wasedatime\.com\/.*', headers["referer"]) == None:
        return True
    else:
        return False

def lambda_handler(event, context):
    # if bad_referer(event["headers"]):
    #     return {
    #         "statusCode": 403,
    #         "headers": {
    #             "Content-Type": "application/json"
    #         },
    #         "body": '{"success":false,"data":null,"message":"External request detected, related information will be reported to admin."}'
    #     }
    try:
        db = boto3.resource("dynamodb", region_name="ap-northeast-1")
        table = db.Table("CourseReview")
        review = json.loads(event["body"])
        review["timestamp"] = review["created_at"]
        del review["updated_at"]
        del review["created_at"]
        review["id"] = str(uuid.uuid4())
    except Exception:
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": '{"success":false,"data":null,"message":"Sorry, our service is temporarily unavailable."}'
        }
    
    table.put_item(Item=review)
    api_response = {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": '{"success":true,"data":null,"message":"Successfully updated the comment."}'
        }
    return {
        "isBase64Encoded": False,
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Origin": '*',
            "Content-Type": "application/json",
            "Referrer-Policy": "origin"
        },
        "multiValueHeaders":{"Access-Control-Allow-Methods": ["POST","OPTIONS","GET","PUT"]},
        'body': json.dumps(api_response, cls=DecimalEncoder, ensure_ascii=False).encode('utf8')
    }
